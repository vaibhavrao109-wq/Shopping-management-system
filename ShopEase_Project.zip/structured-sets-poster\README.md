# Structured Sets & Their Properties — Poster

Poster for **Vaibhav Rao** · Registration No. **251302061** · Section **C**

## Files

| File | Purpose |
| --- | --- |
| `poster.png` | High-resolution image, 2800 × 3960 px (A2 proportions, ~169 dpi at A2) |
| `poster-a2.pdf` | Vector PDF, exactly 420 × 594 mm (A2), one page, fonts embedded |
| `poster.html` | Editable source (HTML/CSS, no external dependencies) |
| `assets/logo.png` | The logo used in the top-left corner |

## Printing

- Open `poster-a2.pdf` and print at **A2, 100 % / "Actual size"**, margins **none**.
- For A3, print the same PDF with "Fit to page" — it scales down cleanly because it is vector.
- The PNG is for screens, slides and WhatsApp-style sharing.

## Editing

- Text lives directly in `poster.html`; open it in any browser to preview.
- Colours are defined once at the top in `:root` (`--navy`, `--teal`, `--gold`, panel accents).
- Panel accent colours are set inline per panel: `style="grid-column:span 7;--accent:#0e7c86"`.
- The poster is designed on a fixed 1400 × 1980 px canvas (ratio 1 : 1.4142).
- Print styling is in the `@media print` block at the end of the stylesheet.

## Content map

1. From a bare set to a structure — carrier + signature + axioms
2. Four properties of a relation (R, S, A, T) → equivalence / partial / total order
3. Order structure — Hasse diagram of the divisors of 12, lattice bounds
4. Partitions & quotients — classes, quotient set, Bell numbers
5. Structure-preserving maps — homomorphism, isomorphism, automorphism
6. The algebraic hierarchy — magma → semigroup → monoid → group → abelian group
7. Applications — databases, scheduling, cryptography, automata, programming, networks
