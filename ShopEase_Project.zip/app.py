import os
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, Category, Product, Admin, Order, OrderItem
from dsa.linked_list import DoublyLinkedList
from dsa.stack import Stack
from dsa.queue import Queue
from functools import wraps
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///shopping.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
csrf = CSRFProtect(app)

# DSA Data Structures (in-memory for demonstration)
product_catalogue_dll = DoublyLinkedList("ProductCatalogue")
action_stack = Stack(max_size=50)
order_queue = Queue(max_size=100)

# Admin login required decorator
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_id' not in session:
            flash('Please login as admin to access this page.', 'warning')
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

# Helper to rebuild linked list from database
def rebuild_catalogue_dll():
    global product_catalogue_dll
    product_catalogue_dll = DoublyLinkedList("ProductCatalogue")
    products = Product.query.filter_by(is_active=True).all()
    for product in products:
        prod_dict = product.to_dict()
        product_catalogue_dll.insert_at_end(prod_dict)
    action_stack.push(f"Catalogue rebuilt from DB - {len(products)} products")

@app.route('/')
def index():
    categories = Category.query.all()
    products = Product.query.filter_by(is_active=True).limit(8).all()
    cart_count = sum(item['quantity'] for item in session.get('cart', []))
    return render_template('index.html', categories=categories, products=products, cart_count=cart_count)

@app.route('/products')
def products():
    categories = Category.query.all()
    category_id = request.args.get('category', type=int)
    search = request.args.get('search', '')
    sort_by = request.args.get('sort', 'name')
    
    query = Product.query.filter_by(is_active=True)
    
    if category_id:
        query = query.filter_by(category_id=category_id)
    
    if search:
        query = query.filter(Product.name.ilike(f'%{search}%') | Product.brand.ilike(f'%{search}%'))
    
    if sort_by == 'price_low':
        query = query.order_by(Product.price.asc())
    elif sort_by == 'price_high':
        query = query.order_by(Product.price.desc())
    else:
        query = query.order_by(Product.name.asc())
    
    products_list = query.all()
    cart_count = sum(item['quantity'] for item in session.get('cart', []))
    
    return render_template('products.html', categories=categories, products=products_list, 
                         selected_category=category_id, search_query=search, 
                         sort_by=sort_by, cart_count=cart_count)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    if not product.is_active:
        flash('Product not available.', 'danger')
        return redirect(url_for('products'))
    categories = Category.query.all()
    cart_count = sum(item['quantity'] for item in session.get('cart', []))
    return render_template('product_detail.html', product=product, categories=categories, cart_count=cart_count)

@app.route('/cart')
def cart():
    cart_items = session.get('cart', [])
    categories = Category.query.all()
    cart_products = []
    total = 0
    
    for item in cart_items:
        product = Product.query.get(item['product_id'])
        if product and product.is_active:
            subtotal = product.price * item['quantity']
            cart_products.append({
                'product': product,
                'quantity': item['quantity'],
                'subtotal': subtotal
            })
            total += subtotal
    
    cart_count = sum(item['quantity'] for item in cart_items)
    return render_template('cart.html', cart_products=cart_products, total=total, 
                         categories=categories, cart_count=cart_count)

@app.route('/add_to_cart', methods=['POST'])
@csrf.exempt
def add_to_cart():
    product_id = request.form.get('product_id', type=int)
    quantity = request.form.get('quantity', 1, type=int)
    
    if not product_id or quantity < 1:
        flash('Invalid request.', 'danger')
        return redirect(request.referrer or url_for('products'))
    
    product = Product.query.get(product_id)
    if not product or not product.is_active:
        flash('Product not available.', 'danger')
        return redirect(request.referrer or url_for('products'))
    
    if quantity > product.stock:
        flash(f'Only {product.stock} units available in stock.', 'warning')
        return redirect(request.referrer or url_for('products'))
    
    cart = session.get('cart', [])
    
    # Check if product already in cart
    for item in cart:
        if item['product_id'] == product_id:
            new_qty = item['quantity'] + quantity
            if new_qty > product.stock:
                flash(f'Cannot add more. Only {product.stock} units available.', 'warning')
                return redirect(request.referrer or url_for('cart'))
            item['quantity'] = new_qty
            session['cart'] = cart
            session.modified = True
            action_stack.push(f"Updated cart: {product.name} qty to {new_qty}")
            flash('Cart updated successfully!', 'success')
            return redirect(url_for('cart'))
    
    cart.append({'product_id': product_id, 'quantity': quantity})
    session['cart'] = cart
    session.modified = True
    action_stack.push(f"Added to cart: {product.name} x{quantity}")
    flash('Product added to cart successfully!', 'success')
    return redirect(url_for('cart'))

@app.route('/update_cart', methods=['POST'])
@csrf.exempt
def update_cart():
    product_id = request.form.get('product_id', type=int)
    quantity = request.form.get('quantity', type=int)
    
    if not product_id or quantity < 1:
        flash('Invalid quantity.', 'danger')
        return redirect(url_for('cart'))
    
    product = Product.query.get(product_id)
    if not product or quantity > product.stock:
        flash(f'Only {product.stock} units available.', 'warning')
        return redirect(url_for('cart'))
    
    cart = session.get('cart', [])
    for item in cart:
        if item['product_id'] == product_id:
            item['quantity'] = quantity
            session['cart'] = cart
            session.modified = True
            action_stack.push(f"Updated cart: {product.name} qty to {quantity}")
            flash('Cart updated!', 'success')
            return redirect(url_for('cart'))
    
    flash('Item not found in cart.', 'danger')
    return redirect(url_for('cart'))

@app.route('/remove_from_cart', methods=['POST'])
@csrf.exempt
def remove_from_cart():
    product_id = request.form.get('product_id', type=int)
    cart = session.get('cart', [])
    
    product = Product.query.get(product_id)
    cart = [item for item in cart if item['product_id'] != product_id]
    session['cart'] = cart
    session.modified = True
    
    if product:
        action_stack.push(f"Removed from cart: {product.name}")
    flash('Item removed from cart.', 'success')
    return redirect(url_for('cart'))

@app.route('/checkout')
def checkout():
    cart_items = session.get('cart', [])
    if not cart_items:
        flash('Your cart is empty!', 'warning')
        return redirect(url_for('cart'))
    
    categories = Category.query.all()
    cart_products = []
    total = 0
    
    for item in cart_items:
        product = Product.query.get(item['product_id'])
        if product and product.is_active:
            if item['quantity'] > product.stock:
                flash(f'{product.name} has only {product.stock} units left. Please update your cart.', 'danger')
                return redirect(url_for('cart'))
            subtotal = product.price * item['quantity']
            cart_products.append({
                'product': product,
                'quantity': item['quantity'],
                'subtotal': subtotal
            })
            total += subtotal
    
    cart_count = sum(item['quantity'] for item in cart_items)
    return render_template('checkout.html', cart_products=cart_products, total=total, 
                         categories=categories, cart_count=cart_count)

@app.route('/place_order', methods=['POST'])
@csrf.exempt
def place_order():
    cart_items = session.get('cart', [])
    if not cart_items:
        flash('Your cart is empty!', 'warning')
        return redirect(url_for('cart'))
    
    customer_name = request.form.get('customer_name', '').strip()
    customer_email = request.form.get('customer_email', '').strip()
    customer_phone = request.form.get('customer_phone', '').strip()
    delivery_address = request.form.get('delivery_address', '').strip()
    
    if not all([customer_name, customer_email, customer_phone, delivery_address]):
        flash('Please fill in all fields.', 'danger')
        return redirect(url_for('checkout'))
    
    try:
        # Use database transaction
        total = 0
        order_items_data = []
        
        # Validate stock and calculate total
        for item in cart_items:
            product = Product.query.get(item['product_id'])
            if not product or not product.is_active:
                flash(f'Product unavailable.', 'danger')
                return redirect(url_for('cart'))
            if item['quantity'] > product.stock:
                flash(f'{product.name} has only {product.stock} units left.', 'danger')
                return redirect(url_for('cart'))
            subtotal = product.price * item['quantity']
            total += subtotal
            order_items_data.append({
                'product': product,
                'quantity': item['quantity'],
                'unit_price': product.price,
                'subtotal': subtotal
            })
        
        # Create order
        order = Order(
            customer_name=customer_name,
            customer_email=customer_email,
            customer_phone=customer_phone,
            delivery_address=delivery_address,
            total_amount=total,
            status='Pending'
        )
        db.session.add(order)
        db.session.flush()  # Get order ID
        
        # Create order items and update stock
        for item_data in order_items_data:
            order_item = OrderItem(
                order_id=order.id,
                product_id=item_data['product'].id,
                quantity=item_data['quantity'],
                unit_price=item_data['unit_price'],
                subtotal=item_data['subtotal']
            )
            db.session.add(order_item)
            # Update stock
            item_data['product'].stock -= item_data['quantity']
        
        db.session.commit()
        
        # Add to queue (DSA demonstration)
        order_queue.enqueue({'order_id': order.id, 'total': total, 'status': 'Pending'})
        action_stack.push(f"Order placed: #{order.id} - Rs.{total}")
        
        # Clear cart
        session.pop('cart', None)
        
        flash(f'Order placed successfully! Order ID: #{order.id}', 'success')
        return redirect(url_for('order_confirmation', order_id=order.id))
        
    except Exception as e:
        db.session.rollback()
        flash('An error occurred while placing order. Please try again.', 'danger')
        return redirect(url_for('checkout'))

@app.route('/order_confirmation/<int:order_id>')
def order_confirmation(order_id):
    order = Order.query.get_or_404(order_id)
    categories = Category.query.all()
    cart_count = 0
    return render_template('order_confirmation.html', order=order, categories=categories, cart_count=cart_count)

# Admin Routes
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if 'admin_id' in session:
        return redirect(url_for('admin_dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        admin = Admin.query.filter_by(username=username).first()
        if admin and admin.check_password(password):
            session['admin_id'] = admin.id
            session['admin_username'] = admin.username
            action_stack.push(f"Admin login: {username}")
            flash('Login successful!', 'success')
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid credentials.', 'danger')
    
    return render_template('admin/login.html')

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_id', None)
    session.pop('admin_username', None)
    flash('Logged out successfully.', 'success')
    return redirect(url_for('admin_login'))

@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    total_products = Product.query.count()
    total_orders = Order.query.count()
    pending_orders = Order.query.filter_by(status='Pending').count()
    categories = Category.query.count()
    
    recent_orders = Order.query.order_by(Order.order_date.desc()).limit(5).all()
    
    action_stack.push("Admin accessed dashboard")
    
    return render_template('admin/dashboard.html', 
                         total_products=total_products,
                         total_orders=total_orders,
                         pending_orders=pending_orders,
                         categories=categories,
                         recent_orders=recent_orders)

@app.route('/admin/products')
@admin_required
def admin_products():
    products = Product.query.all()
    categories = Category.query.all()
    action_stack.push("Admin viewed products")
    return render_template('admin/products.html', products=products, categories=categories)

@app.route('/admin/products/add', methods=['GET', 'POST'])
@admin_required
def admin_add_product():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        brand = request.form.get('brand', '').strip()
        price = request.form.get('price', type=float)
        stock = request.form.get('stock', type=int)
        category_id = request.form.get('category_id', type=int)
        description = request.form.get('description', '').strip()
        
        if not all([name, brand, price, stock is not None, category_id]):
            flash('Please fill all required fields.', 'danger')
            return redirect(url_for('admin_add_product'))
        
        if price < 0 or stock < 0:
            flash('Price and stock cannot be negative.', 'danger')
            return redirect(url_for('admin_add_product'))
        
        product = Product(
            name=name,
            brand=brand,
            price=price,
            stock=stock,
            category_id=category_id,
            description=description,
            is_active=True
        )
        db.session.add(product)
        db.session.commit()
        
        rebuild_catalogue_dll()
        action_stack.push(f"Admin added product: {name}")
        flash('Product added successfully!', 'success')
        return redirect(url_for('admin_products'))
    
    categories = Category.query.all()
    return render_template('admin/add_product.html', categories=categories)

@app.route('/admin/products/edit/<int:product_id>', methods=['GET', 'POST'])
@admin_required
def admin_edit_product(product_id):
    product = Product.query.get_or_404(product_id)
    
    if request.method == 'POST':
        product.name = request.form.get('name', '').strip()
        product.brand = request.form.get('brand', '').strip()
        product.price = request.form.get('price', type=float)
        product.stock = request.form.get('stock', type=int)
        product.category_id = request.form.get('category_id', type=int)
        product.description = request.form.get('description', '').strip()
        product.is_active = request.form.get('is_active') == 'on'
        
        if product.price < 0 or product.stock < 0:
            flash('Price and stock cannot be negative.', 'danger')
            return redirect(url_for('admin_edit_product', product_id=product_id))
        
        db.session.commit()
        rebuild_catalogue_dll()
        action_stack.push(f"Admin edited product: {product.name}")
        flash('Product updated successfully!', 'success')
        return redirect(url_for('admin_products'))
    
    categories = Category.query.all()
    return render_template('admin/edit_product.html', product=product, categories=categories)

@app.route('/admin/products/delete/<int:product_id>', methods=['POST'])
@admin_required
@csrf.exempt
def admin_delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    product_name = product.name
    product.is_active = False
    db.session.commit()
    rebuild_catalogue_dll()
    action_stack.push(f"Admin deactivated product: {product_name}")
    flash('Product deactivated successfully!', 'success')
    return redirect(url_for('admin_products'))

@app.route('/admin/orders')
@admin_required
def admin_orders():
    orders = Order.query.order_by(Order.order_date.desc()).all()
    action_stack.push("Admin viewed orders")
    return render_template('admin/orders.html', orders=orders)

@app.route('/admin/orders/<int:order_id>')
@admin_required
def admin_order_detail(order_id):
    order = Order.query.get_or_404(order_id)
    return render_template('admin/order_detail.html', order=order)

@app.route('/admin/orders/update/<int:order_id>', methods=['POST'])
@admin_required
@csrf.exempt
def admin_update_order(order_id):
    order = Order.query.get_or_404(order_id)
    new_status = request.form.get('status')
    
    if new_status in ['Pending', 'Processing', 'Completed']:
        order.status = new_status
        db.session.commit()
        action_stack.push(f"Admin updated order #{order_id} to {new_status}")
        flash('Order status updated!', 'success')
    
    return redirect(url_for('admin_order_detail', order_id=order_id))

@app.route('/admin/dsa-demo')
@admin_required
def admin_dsa_demo():
    dll_state = product_catalogue_dll.to_dict()
    stack_state = action_stack.to_dict()
    queue_state = order_queue.to_dict()
    
    action_stack.push("Admin viewed DSA demonstration")
    
    return render_template('admin/dsa_demo.html', 
                         dll_state=dll_state,
                         stack_state=stack_state,
                         queue_state=queue_state)

@app.route('/api/catalogue/dll')
def api_catalogue_dll():
    return jsonify(product_catalogue_dll.to_dict())

@app.route('/api/stack')
def api_stack():
    return jsonify(action_stack.to_dict())

@app.route('/api/queue')
def api_queue():
    return jsonify(order_queue.to_dict())

def init_db():
    with app.app_context():
        db.create_all()
        
        # Create categories
        if Category.query.count() == 0:
            categories = [
                Category(name='Jeans', description='Denim Jeans Collection'),
                Category(name='Trousers', description='Formal and Casual Trousers'),
                Category(name='Shirts', description='Shirts for all occasions'),
                Category(name='T-shirts', description='Casual T-Shirts'),
                Category(name='Watches', description='Wrist Watches'),
                Category(name='Shoes', description='Footwear Collection')
            ]
            for cat in categories:
                db.session.add(cat)
            db.session.commit()
            print("Categories created")
        
        # Create admin if none exists
        if Admin.query.count() == 0:
            admin = Admin(username='admin', email='admin@shopease.com')
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            print("Admin created - username: admin, password: admin123")
        
        # Seed products
        if Product.query.count() == 0:
            cat_map = {cat.name: cat.id for cat in Category.query.all()}
            
            products_data = [
                # Jeans
                (101, 'Slim Fit Black Jeans', 'Denim', 2499, 50, 'Slim fit black denim jeans', cat_map['Jeans']),
                (102, 'Regular Fit Blue Jeans', 'Levis', 2999, 45, 'Classic regular fit blue jeans', cat_map['Jeans']),
                (103, 'Ripped Black Jeans', 'Wrangler', 3499, 30, 'Trendy ripped black jeans', cat_map['Jeans']),
                (104, 'Straight Fit Grey Jeans', 'Pepe Jeans', 2799, 40, 'Comfortable straight fit grey jeans', cat_map['Jeans']),
                (105, 'Skinny Fit Blue Jeans', 'Spykar', 3199, 35, 'Stylish skinny fit blue jeans', cat_map['Jeans']),
                # Trousers
                (201, 'Formal Black Trouser', 'Van Heusen', 1999, 60, 'Perfect for formal occasions', cat_map['Trousers']),
                (202, 'Chino Khaki Trouser', 'Raymond', 2299, 55, 'Casual chino trousers', cat_map['Trousers']),
                (203, 'Casual Grey Trouser', 'Peter England', 1799, 65, 'Comfortable casual trousers', cat_map['Trousers']),
                (204, 'Cargo Beige Trouser', 'Flying Machine', 2499, 40, 'Trendy cargo trousers', cat_map['Trousers']),
                (205, 'Track Pant Black', 'Puma', 1599, 70, 'Comfortable track pants', cat_map['Trousers']),
                # Shirts
                (301, 'Formal White Shirt', 'Arrow', 1899, 80, 'Crisp formal white shirt', cat_map['Shirts']),
                (302, 'Checked Blue Shirt', 'Van Heusen', 1799, 75, 'Stylish checked shirt', cat_map['Shirts']),
                (303, 'Striped Black Shirt', 'Raymond', 1999, 65, 'Elegant striped shirt', cat_map['Shirts']),
                (304, 'Denim Casual Shirt', 'Levis', 2199, 50, 'Cool denim casual shirt', cat_map['Shirts']),
                (305, 'Plain Maroon Shirt', 'Peter England', 1699, 70, 'Simple plain maroon shirt', cat_map['Shirts']),
                # T-shirts
                (401, 'Round Neck Black T-Shirt', 'Nike', 1299, 100, 'Comfortable cotton t-shirt', cat_map['T-shirts']),
                (402, 'V-Neck White T-Shirt', 'Puma', 1099, 95, 'Classic v-neck t-shirt', cat_map['T-shirts']),
                (403, 'Graphic Blue T-Shirt', 'Adidas', 1499, 85, 'Trendy graphic t-shirt', cat_map['T-shirts']),
                (404, 'Polo Green T-Shirt', 'Levis', 1599, 80, 'Smart polo t-shirt', cat_map['T-shirts']),
                (405, 'Crew Neck Brown T-Shirt', 'HRX', 999, 110, 'Affordable crew neck t-shirt', cat_map['T-shirts']),
                # Watches
                (501, 'Classic Black Watch', 'Titan', 3999, 40, 'Elegant classic watch', cat_map['Watches']),
                (502, 'Smart Watch Silver', 'Fastrack', 5999, 35, 'Feature-rich smart watch', cat_map['Watches']),
                (503, 'Chronograph Brown Watch', 'Casio', 8999, 25, 'Premium chronograph watch', cat_map['Watches']),
                (504, 'Minimalist Golden Watch', 'Sonata', 2499, 45, 'Sleek minimalist watch', cat_map['Watches']),
                (505, 'Digital Sports Watch', 'Noise', 4999, 30, 'Durable sports watch', cat_map['Watches']),
                # Shoes
                (601, 'Running Black Shoes', 'Nike', 6999, 50, 'Comfortable running shoes', cat_map['Shoes']),
                (602, 'Casual White Shoes', 'Adidas', 6499, 55, 'Stylish casual shoes', cat_map['Shoes']),
                (603, 'Training Blue Shoes', 'Puma', 5999, 60, 'Versatile training shoes', cat_map['Shoes']),
                (604, 'Formal Brown Shoes', 'Bata', 3999, 70, 'Classic formal shoes', cat_map['Shoes']),
                (605, 'Sneakers Grey Shoes', 'Sparx', 2999, 80, 'Trendy sneakers', cat_map['Shoes']),
            ]
            
            for pid, name, brand, price, stock, desc, cat_id in products_data:
                product = Product(id=pid, name=name, brand=brand, price=price, 
                                stock=stock, description=desc, category_id=cat_id, is_active=True)
                db.session.add(product)
            db.session.commit()
            print(f"Seeded {len(products_data)} products")
        
        # Build catalogue
        rebuild_catalogue_dll()
        print("Database initialized successfully!")

if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='127.0.0.1', port=5000)
