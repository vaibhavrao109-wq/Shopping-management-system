# ShopEase - Shopping Management System (Full-Stack Website)

A complete, database-backed e-commerce website built with Flask, demonstrating Data Structures and Algorithms concepts alongside modern web development.

## 🎯 Project Overview

This project transforms the original terminal-based Shopping Management System into a full-stack web application with:
- **Frontend**: HTML5, CSS3, JavaScript (Responsive Design)
- **Backend**: Python Flask
- **Database**: SQLite with SQLAlchemy ORM
- **DSA Concepts**: Doubly Linked List, Stack (LIFO), Queue (FIFO)

## ✨ Features

### Customer Features
- 🏠 **Home Page** - Featured products and category browsing
- 🛍️ **Product Catalogue** - Browse all products with filtering and sorting
- 🔍 **Search** - Search products by name or brand
- 🛒 **Shopping Cart** - Add, update, remove items with stock validation
- 💳 **Checkout** - Place orders with customer details (demo checkout)
- 📄 **Order Confirmation** - View order details and bill
- 📱 **Responsive Design** - Works on desktop, tablet, and mobile

### Admin Features
- 🔐 **Secure Admin Login** - Password-protected admin panel
- 📊 **Dashboard** - Statistics and recent orders
- 📦 **Product Management** - Add, edit, deactivate products
- 🗂️ **Category Management** - View categories
- 📋 **Order Management** - View orders and update status (Pending/Processing/Completed)
- 🧮 **DSA Demonstration** - Live view of Linked List, Stack, and Queue

### DSA Implementation
- **Doubly Linked List**: Product catalogue traversal in both directions
- **Stack (LIFO)**: Action history tracking
- **Queue (FIFO)**: Order processing queue

## 🚀 Quick Start (Windows)

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Installation

1. **Navigate to project directory**
```cmd
cd "C:\Users\hp\Documents\Default Project"
```

2. **Create virtual environment (recommended)**
```cmd
python -m venv venv
venv\Scripts\activate
```

3. **Install dependencies**
```cmd
pip install -r requirements.txt
```

4. **Run the application**
```cmd
python app.py
```

5. **Open in browser**
Navigate to: [http://127.0.0.1:5000](http://127.0.0.1:5000)

## 🔑 Default Admin Credentials

- **Username:** `admin`
- **Password:** `admin123`

*Change these in production!*

## 📁 Project Structure

```
ShopEase/
├── app.py                  # Main Flask application
├── models.py               # Database models (SQLAlchemy)
├── requirements.txt        # Python dependencies
├── shopping.db             # SQLite database (created on first run)
├── dsa/                    # DSA implementations
│   ├── linked_list.py      # Doubly Linked List
│   ├── stack.py            # Stack (LIFO)
│   ├── queue.py            # Queue (FIFO)
│   └── __init__.py
├── templates/              # HTML templates
│   ├── base.html
│   ├── index.html
│   ├── products.html
│   ├── cart.html
│   ├── checkout.html
│   ├── order_confirmation.html
│   └── admin/              # Admin templates
├── static/                 # Static files
│   ├── css/style.css
│   ├── js/main.js
│   └── images/
└── shopping_management_system.py  # Original CLI version
```

## 🧪 Testing the Application

### Customer Flow
1. Browse products on homepage or products page
2. Search or filter by category
3. Add products to cart
4. View cart and update quantities
5. Proceed to checkout
6. Fill customer details and place order
7. View order confirmation

### Admin Flow
1. Go to Admin Login (/admin/login)
2. Login with admin credentials
3. View dashboard statistics
4. Manage products (Add/Edit/Deactivate)
5. Manage orders (View/Update status)
6. View DSA Demonstration page

### DSA Testing
- **Linked List**: View traversal in both directions on DSA Demo page
- **Stack**: Perform actions (add to cart, place order) and see history
- **Queue**: Place orders and see them in queue

## 🛠️ Database

- **Type**: SQLite (`shopping.db`)
- **ORM**: SQLAlchemy
- **Tables**: categories, products, admins, orders, order_items
- **Auto-initialization**: Database and sample data created on first run

## 🔒 Security Notes

- Passwords are hashed using Werkzeug
- Admin routes protected with decorator
- CSRF protection enabled
- Server-side validation for all inputs
- Prices and totals calculated on backend
- SQLAlchemy uses parameterized queries

## 📝 Notes for College Viva

### Architecture
- **Frontend**: Jinja2 templates with Bootstrap-like custom CSS
- **Backend**: Flask routes handle requests, business logic in routes
- **Database**: SQLAlchemy models define schema, relationships
- **DSA Layer**: Separate modules demonstrating concepts

### Key Points
- Database is source of truth for persistent data
- DSA structures are in-memory for demonstration
- Linked list rebuilt from DB when products change
- Stack tracks all user/admin actions
- Queue holds orders for processing (FIFO)
- Transactions ensure data integrity on checkout

## 🐛 Troubleshooting

**Port already in use:**
```cmd
python app.py --port 5001
```
Or change port in app.py

**Module not found:**
```cmd
pip install -r requirements.txt
```

**Database issues:**
Delete `shopping.db` and restart - it will recreate with sample data

## 📄 License

This is a college project for educational purposes.

## 👨‍💻 Original Project

This is an enhanced version of the terminal-based Shopping Management System, transformed into a full-stack web application while preserving the core concepts and structure.
