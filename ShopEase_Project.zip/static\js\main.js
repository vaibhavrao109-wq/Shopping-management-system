// Main JavaScript for ShopEase

// Auto-hide flash messages after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    const flashMessages = document.querySelectorAll('.flash-message');
    flashMessages.forEach(function(message) {
        setTimeout(function() {
            message.style.opacity = '0';
            setTimeout(function() {
                message.style.display = 'none';
            }, 300);
        }, 5000);
    });
});

// Update cart quantity
function updateCartQuantity(productId) {
    const input = document.getElementById('qty-' + productId);
    const quantity = input.value;
    
    if (quantity < 1) {
        alert('Quantity must be at least 1');
        input.value = 1;
        return;
    }
    
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '/update_cart';
    
    const csrfInput = document.createElement('input');
    csrfInput.type = 'hidden';
    csrfInput.name = 'csrf_token';
    csrfInput.value = getCsrfToken();
    
    const pidInput = document.createElement('input');
    pidInput.type = 'hidden';
    pidInput.name = 'product_id';
    pidInput.value = productId;
    
    const qtyInput = document.createElement('input');
    qtyInput.type = 'hidden';
    qtyInput.name = 'quantity';
    qtyInput.value = quantity;
    
    form.appendChild(csrfInput);
    form.appendChild(pidInput);
    form.appendChild(qtyInput);
    document.body.appendChild(form);
    form.submit();
}

// Remove item from cart
function removeFromCart(productId) {
    if (confirm('Remove this item from cart?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '/remove_from_cart';
        
        const csrfInput = document.createElement('input');
        csrfInput.type = 'hidden';
        csrfInput.name = 'csrf_token';
        csrfInput.value = getCsrfToken();
        
        const pidInput = document.createElement('input');
        pidInput.type = 'hidden';
        pidInput.name = 'product_id';
        pidInput.value = productId;
        
        form.appendChild(csrfInput);
        form.appendChild(pidInput);
        document.body.appendChild(form);
        form.submit();
    }
}

// Get CSRF token
function getCsrfToken() {
    // Try to get from meta tag or form
    const metaToken = document.querySelector('meta[name="csrf-token"]');
    if (metaToken) {
        return metaToken.getAttribute('content');
    }
    
    const csrfInput = document.querySelector('input[name="csrf_token"]');
    if (csrfInput) {
        return csrfInput.value;
    }
    
    return '';
}
