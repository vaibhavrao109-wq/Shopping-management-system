﻿from pptx import Presentation
from pptx.util import Inches
prs = Presentation()
s = prs.slides.add_slide(prs.slide_layouts[0])
s.shapes.title.text = "Comparative Study of RISC and CISC"
s.placeholders[1].text = "Computer Organization"
s = prs.slides.add_slide(prs.slide_layouts[1])
s.shapes.title.text = "Agenda"
tf = s.placeholders[1].text_frame
tf.text = "1. Introduction"
for t in ["2. What is RISC?", "3. What is CISC?", "4. Key Differences", "5. Examples", "6. Advantages and Disadvantages", "7. Applications", "8. RISC vs CISC in Modern Era", "9. Conclusion", "10. References"]:
    tf.add_paragraph().text = t
s = prs.slides.add_slide(prs.slide_layouts[1])
s.shapes.title.text = "Introduction"
tf = s.placeholders[1].text_frame
tf.text = "CPU architecture defines how instructions are executed."
for t in ["Two major approaches: RISC and CISC.", "They differ in instruction complexity and design philosophy.", "This presentation compares them."]:
    tf.add_paragraph().text = t
s = prs.slides.add_slide(prs.slide_layouts[1])
s.shapes.title.text = "What is RISC?"
tf = s.placeholders[1].text_frame
tf.text = "Reduced Instruction Set Computer (RISC)"
for t in ["Small, simple instruction set", "Most instructions execute in one clock cycle", "Load-store architecture", "Large number of registers", "Efficient pipelining"]:
    tf.add_paragraph().text = t
s = prs.slides.add_slide(prs.slide_layouts[1])
s.shapes.title.text = "What is CISC?"
tf = s.placeholders[1].text_frame
tf.text = "Complex Instruction Set Computer (CISC)"
for t in ["Large, complex instruction set", "Single instruction can perform multiple tasks", "Supports memory-to-memory operations", "Many addressing modes", "Reduces number of instructions per program"]:
    tf.add_paragraph().text = t
s = prs.slides.add_slide(prs.slide_layouts[5])
s.shapes.title.text = "Key Differences"
t = s.shapes.add_table(6,3,Inches(0.5),Inches(1.6),Inches(9),Inches(3.4)).table
for i,h in enumerate(["Feature","RISC","CISC"]): t.cell(0,i).text=h
for r,(f,a,b) in enumerate([["Instruction Set","Small & simple","Large & complex"],["Cycles/Instruction","1 (mostly)","Multiple"],["Addressing Modes","Few","Many"],["Registers","Large","Few"],["Memory Access","Only LOAD/STORE","Direct access allowed"]],1):
    t.cell(r,0).text=f;t.cell(r,1).text=a;t.cell(r,2).text=b
s = prs.slides.add_slide(prs.slide_layouts[1])
s.shapes.title.text = "Examples"
tf = s.placeholders[1].text_frame
tf.text = "RISC: ARM, MIPS, RISC-V, PowerPC"
tf.add_paragraph().text = "CISC: Intel x86, AMD x86-64, Motorola 68000"
s = prs.slides.add_slide(prs.slide_layouts[5])
s.shapes.title.text = "Advantages & Disadvantages"
t = s.shapes.add_table(3,3,Inches(0.5),Inches(1.6),Inches(9),Inches(2.8)).table
for i,h in enumerate(["Type","Advantages","Disadvantages"]): t.cell(0,i).text=h
t.cell(1,0).text="RISC"; t.cell(1,1).text="Fast, low power, simple, great for pipelining"; t.cell(1,2).text="Larger code, compiler dependent"
t.cell(2,0).text="CISC"; t.cell(2,1).text="Compact code, backward compatible, versatile"; t.cell(2,2).text="Complex hardware, higher power, slower decoding"
s = prs.slides.add_slide(prs.slide_layouts[1])
s.shapes.title.text = "Applications"
tf = s.placeholders[1].text_frame
tf.text = "RISC: Smartphones, IoT, Embedded Systems"
tf.add_paragraph().text = "CISC: Desktops, Laptops, Servers, Workstations"
s = prs.slides.add_slide(prs.slide_layouts[1])
s.shapes.title.text = "RISC vs CISC in Modern Era"
tf = s.placeholders[1].text_frame
tf.text = "x86 internally uses RISC-like micro-operations"
for t in ["RISC dominates mobile and embedded systems", "CISC remains strong in PCs and servers", "Line between them has blurred", "RISC-V is rapidly growing"]:
    tf.add_paragraph().text = t
s = prs.slides.add_slide(prs.slide_layouts[1])
s.shapes.title.text = "Conclusion"
tf = s.placeholders[1].text_frame
tf.text = "Both have their own strengths and use cases."
for t in ["RISC excels in efficiency and speed", "CISC excels in code density and compatibility", "Modern CPUs use a hybrid approach"]:
    tf.add_paragraph().text = t
s = prs.slides.add_slide(prs.slide_layouts[1])
s.shapes.title.text = "References"
tf = s.placeholders[1].text_frame
tf.text = "Patterson & Hennessy - Computer Organization and Design"
for t in ["Stallings - Computer Organization and Architecture", "GeeksforGeeks - RISC vs CISC", "riscv.org"]:
    tf.add_paragraph().text = t
prs.save(r"C:\Users\hp\Documents\Default Project\Comparative Study of RISC and CISC.pptx")
