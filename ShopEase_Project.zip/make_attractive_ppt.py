﻿from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

prs = Presentation()

# Slide 1: Title Slide
slide = prs.slides.add_slide(prs.slide_layouts[0])
# Add background shape
shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, Inches(4.5), prs.slide_width, Inches(1.0))
fill = shape.fill
fill.solid()
fill.fore_color.rgb = RGBColor(0, 82, 180)
shape.line.fill.background()

title = slide.shapes.title
title.text = "Comparative Study of RISC and CISC"
title.text_frame.paragraphs[0].font.size = Pt(40)
title.text_frame.paragraphs[0].font.bold = True
title.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 51, 102)

subtitle = slide.placeholders[1]
subtitle.text = "Computer Organization\nPresented By: [Your Name/Group Name]"
subtitle.text_frame.paragraphs[0].font.size = Pt(24)

notes = slide.notes_slide.notes_text_frame
notes.text = "INTRODUCTION TO PRESENTATION (10-15 seconds)\n\nSay: \"Good [morning/afternoon], today we will be comparing two major processor architectures - RISC and CISC. By the end of this presentation, you'll understand their differences, examples, applications and relevance in modern computing.\"\n\nTip: Speak confidently, make eye contact and introduce your topic briefly."

# Slide 2: Agenda
slide = prs.slides.add_slide(prs.slide_layouts[1])
slide.shapes.title.text = "Agenda"
title_shape = slide.shapes.title
title_shape.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 82, 180)

tf = slide.placeholders[1].text_frame
tf.clear()
items = [
    "1. Introduction",
    "2. What is RISC?",
    "3. What is CISC?",
    "4. Key Differences Between RISC and CISC",
    "5. Examples of RISC & CISC Processors",
    "6. Advantages & Disadvantages",
    "7. Applications",
    "8. RISC vs CISC in the Modern Era",
    "9. Conclusion",
    "10. References"
]
for i, item in enumerate(items):
    if i == 0:
        p = tf.paragraphs[0]
    else:
        p = tf.add_paragraph()
    p.text = item
    p.font.size = Pt(28)

notes = slide.notes_slide.notes_text_frame
notes.text = "AGENDA (10 seconds)\n\nSay: \"Here's a quick roadmap of what we'll be covering today. We'll start with an introduction, understand both architectures, compare them, look at examples and applications, and end with a conclusion and references.\"\n\nTip: Don't go into detail here, just give an overview."

# Slide 3: Introduction
slide = prs.slides.add_slide(prs.slide_layouts[1])
slide.shapes.title.text = "Introduction"
slide.shapes.title.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 82, 180)
tf = slide.placeholders[1].text_frame
tf.clear()
intro_points = [
    "The CPU is the brain of a computer and follows a specific architecture to execute instructions.",
    "There are two major design philosophies - Reduced Instruction Set Computer (RISC) and Complex Instruction Set Computer (CISC).",
    "RISC follows the principle of 'Simpler instructions, faster execution'.",
    "CISC follows the principle of 'Powerful instructions, fewer instructions per program'.",
    "The goal of this study is to compare these two architectures based on design, performance, and usage."
]
for i, point in enumerate(intro_points):
    if i == 0:
        p = tf.paragraphs[0]
    else:
        p = tf.add_paragraph()
    p.text = "• " + point
    p.font.size = Pt(26)

notes = slide.notes_slide.notes_text_frame
notes.text = "INTRODUCTION (30-40 seconds)\n\nSay: \"Every processor is built around an instruction set architecture. Broadly, we classify them into RISC and CISC. RISC aims for speed through simplicity - keeping instructions minimal so each can be executed quickly. On the other hand, CISC aims to do more with a single instruction, reducing the number of instructions a program needs. Today, we'll compare these two approaches.\"\n\nTip: Relate to real life - 'like having many small tools vs one multi-purpose tool' to make it relatable."

# Slide 4: What is RISC?
slide = prs.slides.add_slide(prs.slide_layouts[1])
slide.shapes.title.text = "What is RISC? (Reduced Instruction Set Computer)"
slide.shapes.title.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 82, 180)
tf = slide.placeholders[1].text_frame
tf.clear()
risc_points = [
    "RISC uses a small, simple set of instructions.",
    "Most instructions are executed in a single clock cycle.",
    "It follows the Load-Store architecture (only LOAD and STORE access memory).",
    "Contains a large number of general-purpose registers.",
    "Designed to work efficiently with pipelining.",
    "Relies more on the compiler to generate efficient code."
]
for i, point in enumerate(risc_points):
    if i == 0:
        p = tf.paragraphs[0]
    else:
        p = tf.add_paragraph()
    p.text = "• " + point
    p.font.size = Pt(26)

notes = slide.notes_slide.notes_text_frame
notes.text = "WHAT IS RISC? (35-45 seconds)\n\nSay: \"RISC stands for Reduced Instruction Set Computer. The key idea is to keep the instruction set minimal. Since instructions are simple, the hardware can execute them very quickly, often in just one clock cycle. RISC uses a load-store model, which means to perform operations, data must first be loaded into registers. With many registers available and support for pipelining, RISC achieves high speed and efficiency.\"\n\nTip: Emphasize 'reduced' = fewer and simpler instructions, not less powerful overall."

# Slide 5: What is CISC?
slide = prs.slides.add_slide(prs.slide_layouts[1])
slide.shapes.title.text = "What is CISC? (Complex Instruction Set Computer)"
slide.shapes.title.text_frame.paragraphs[0].font.color.rgb = RGBColor(214, 40, 40)
tf = slide.placeholders[1].text_frame
tf.clear()
cisc_points = [
    "CISC uses a large set of complex, multi-purpose instructions.",
    "A single instruction can perform multiple operations (e.g., load, add, store).",
    "Supports direct memory-to-memory operations.",
    "Offers a wide variety of addressing modes.",
    "Uses fewer general-purpose registers.",
    "Focuses on reducing the total number of instructions in a program."
]
for i, point in enumerate(cisc_points):
    if i == 0:
        p = tf.paragraphs[0]
    else:
        p = tf.add_paragraph()
    p.text = "• " + point
    p.font.size = Pt(26)

notes = slide.notes_slide.notes_text_frame
notes.text = "WHAT IS CISC? (35-45 seconds)\n\nSay: \"CISC stands for Complex Instruction Set Computer. Unlike RISC, CISC has a huge collection of powerful instructions. One instruction can do what might take multiple RISC instructions to achieve. This makes programs shorter in length. However, since these instructions are complex, decoding and executing them takes more time and requires more complex hardware.\"\n\nTip: Use the multi-purpose tool analogy here - one tool can do many things, but it's more complex to build."

# Slide 6: Key Differences
slide = prs.slides.add_slide(prs.slide_layouts[5])
slide.shapes.title.text = "Key Differences Between RISC and CISC"
slide.shapes.title.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 82, 180)
rows, cols = 6, 3
left = Inches(0.4)
top = Inches(1.7)
width = Inches(9.2)
height = Inches(3.8)
table = slide.shapes.add_table(rows, cols, left, top, width, height).table
table.columns[0].width = Inches(2.4)
table.columns[1].width = Inches(3.4)
table.columns[2].width = Inches(3.4)

# Style headers
headers = ["Feature", "RISC", "CISC"]
for c in range(3):
    cell = table.cell(0, c)
    cell.text = headers[c]
    cell.fill.solid()
    cell.fill.fore_color.rgb = RGBColor(0, 82, 180)
    cell.text_frame.paragraphs[0].font.color.rgb = RGBColor(255, 255, 255)
    cell.text_frame.paragraphs[0].font.bold = True
    cell.text_frame.paragraphs[0].font.size = Pt(24)
    cell.vertical_anchor = MSO_ANCHOR.MIDDLE

# Style data
data = [
    ["Instruction Set", "Small and simple", "Large and complex"],
    ["Execution Time", "Mostly 1 clock cycle per instruction", "Multiple clock cycles per instruction"],
    ["Addressing Modes", "Few", "Many"],
    ["Number of Registers", "Large number of general-purpose registers", "Fewer registers"],
    ["Memory Access", "Only via LOAD/STORE instructions", "Many instructions can access memory directly"]
]
for r in range(1, 6):
    for c in range(3):
        cell = table.cell(r, c)
        cell.text = data[r-1][c]
        cell.text_frame.paragraphs[0].font.size = Pt(22)
        cell.vertical_anchor = MSO_ANCHOR.MIDDLE
        if r % 2 == 0:
            cell.fill.solid()
            cell.fill.fore_color.rgb = RGBColor(245, 248, 255)

notes = slide.notes_slide.notes_text_frame
notes.text = "KEY DIFFERENCES (45-60 seconds)\n\nSay: \"Now let's look at the core differences. RISC has a small instruction set, while CISC has a large one. RISC aims for one cycle per instruction, whereas CISC often takes multiple cycles. RISC uses load-store, so only LOAD and STORE touch memory. CISC allows direct memory access. RISC has more registers, CISC has fewer. Also, RISC relies on addressing modes minimally, while CISC has many. These differences directly impact speed, code size and hardware complexity.\"\n\nTip: Don't just read the table - explain the 'why' for each key difference."

# Slide 7: Examples
slide = prs.slides.add_slide(prs.slide_layouts[1])
slide.shapes.title.text = "Examples of RISC & CISC Processors"
slide.shapes.title.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 82, 180)
tf = slide.placeholders[1].text_frame
tf.clear()
p = tf.paragraphs[0]
p.text = "RISC Examples:"
p.font.bold = True
p.font.size = Pt(28)
p.font.color.rgb = RGBColor(0, 82, 180)
for ex in ["ARM - Widely used in smartphones, tablets & embedded devices", 
           "MIPS - Used in routers, embedded systems & gaming consoles",
           "RISC-V - Open-source, highly flexible & gaining popularity",
           "PowerPC - Used in some embedded systems & older Apple Macs"]:
    pp = tf.add_paragraph()
    pp.text = "• " + ex
    pp.font.size = Pt(24)
    pp.level = 1

p2 = tf.add_paragraph()
p2.text = "CISC Examples:"
p2.font.bold = True
p2.font.size = Pt(28)
p2.font.color.rgb = RGBColor(214, 40, 40)

for ex in ["Intel x86/x86-64 - Found in most PCs and laptops",
           "AMD x86-64 Processors - Common in desktops, laptops & servers",
           "Motorola 68000 Series - Popular in older computers & embedded systems"]:
    pp = tf.add_paragraph()
    pp.text = "• " + ex
    pp.font.size = Pt(24)
    pp.level = 1

notes = slide.notes_slide.notes_text_frame
notes.text = "EXAMPLES (30-40 seconds)\n\nSay: \"For RISC, ARM is the most common example - chances are the phone in your pocket has an ARM processor. RISC-V is very interesting as it's open-source and used in modern research. For CISC, Intel and AMD x86 processors power most of our desktop and laptop computers. So in reality, both are all around us.\"\n\nTip: Ask the class 'What processor is in your phone?' to get them engaged."

# Slide 8: Advantages & Disadvantages
slide = prs.slides.add_slide(prs.slide_layouts[5])
slide.shapes.title.text = "Advantages & Disadvantages"
slide.shapes.title.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 82, 180)
rows, cols = 3, 3
left = Inches(0.4)
top = Inches(1.7)
width = Inches(9.2)
height = Inches(3.2)
table = slide.shapes.add_table(rows, cols, left, top, width, height).table
table.columns[0].width = Inches(1.8)
table.columns[1].width = Inches(3.7)
table.columns[2].width = Inches(3.7)

headers = ["Architecture", "Advantages", "Disadvantages"]
for c in range(3):
    cell = table.cell(0, c)
    cell.text = headers[c]
    cell.fill.solid()
    cell.fill.fore_color.rgb = RGBColor(0, 82, 180)
    cell.text_frame.paragraphs[0].font.color.rgb = RGBColor(255, 255, 255)
    cell.text_frame.paragraphs[0].font.bold = True
    cell.text_frame.paragraphs[0].font.size = Pt(22)
    cell.vertical_anchor = MSO_ANCHOR.MIDDLE

# RISC row
risc_adv = "• Faster execution\n• Lower power consumption\n• Simpler hardware design\n• Efficient for pipelining"
risc_dis = "• Larger program size\n• More instructions needed\n• Heavy reliance on compiler"
# CISC row
cisc_adv = "• Smaller program size\n• Fewer instructions to write\n• Backward compatible\n• More powerful individual instructions"
cisc_dis = "• Complex hardware\n• Higher power consumption\n• Slower instruction decoding\n• Less efficient for pipelining"

table.cell(1,0).text = "RISC"
table.cell(1,1).text = risc_adv
table.cell(1,2).text = risc_dis
table.cell(2,0).text = "CISC"
table.cell(2,1).text = cisc_adv
table.cell(2,2).text = cisc_dis

for r in range(1, 3):
    for c in range(3):
        cell = table.cell(r, c)
        cell.text_frame.paragraphs[0].font.size = Pt(19)
        if r % 2 == 0:
            cell.fill.solid()
            cell.fill.fore_color.rgb = RGBColor(245, 248, 255)
        cell.vertical_anchor = MSO_ANCHOR.MIDDLE

notes = slide.notes_slide.notes_text_frame
notes.text = "ADVANTAGES & DISADVANTAGES (40-50 seconds)\n\nSay: \"RISC wins when it comes to speed and power efficiency, which is why it's perfect for battery-powered devices. But since instructions are simple, you need more of them, making code longer. CISC is great for writing compact programs and maintaining compatibility with older software. However, all that complexity comes at the cost of more transistors, more power, and slower decoding. There's always a trade-off.\"\n\nTip: Focus on 'trade-off' - neither is perfect."

# Slide 9: Applications
slide = prs.slides.add_slide(prs.slide_layouts[1])
slide.shapes.title.text = "Applications of RISC & CISC"
slide.shapes.title.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 82, 180)
tf = slide.placeholders[1].text_frame
tf.clear()
p = tf.paragraphs[0]
p.text = "Where RISC is Used:"
p.font.bold = True
p.font.size = Pt(28)
p.font.color.rgb = RGBColor(0, 82, 180)
for app in ["Smartphones & Tablets (ARM processors)", "IoT Devices & Smart Home Gadgets", 
           "Wearables (Smartwatches, Fitness bands)", "Embedded Systems & Microcontrollers"]:
    pp = tf.add_paragraph()
    pp.text = "• " + app
    pp.font.size = Pt(25)
    pp.level = 1

p2 = tf.add_paragraph()
p2.text = "Where CISC is Used:"
p2.font.bold = True
p2.font.size = Pt(28)
p2.font.color.rgb = RGBColor(214, 40, 40)
for app in ["Desktop Computers & Laptops (Intel/AMD)", "Servers & Workstations", 
           "High-performance PCs for gaming & professional work", "Legacy systems requiring x86 compatibility"]:
    pp = tf.add_paragraph()
    pp.text = "• " + app
    pp.font.size = Pt(25)
    pp.level = 1

notes = slide.notes_slide.notes_text_frame
notes.text = "APPLICATIONS (30-40 seconds)\n\nSay: \"Due to its low power consumption, RISC dominates the mobile and embedded world. Almost every smartphone you see runs on ARM-based RISC chips. On the other hand, CISC, especially x86, dominates our desktops, laptops and servers where performance and backward compatibility with decades of software matter the most.\"\n\nTip: Make it relatable by pointing to devices around us."

# Slide 10: Modern Era
slide = prs.slides.add_slide(prs.slide_layouts[1])
slide.shapes.title.text = "RISC vs CISC in the Modern Era"
slide.shapes.title.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 82, 180)
tf = slide.placeholders[1].text_frame
tf.clear()
modern_points = [
    "Modern CISC processors (like Intel & AMD) no longer execute CISC instructions directly - they translate them into RISC-like micro-operations internally.",
    "This gives them the best of both worlds - CISC compatibility with RISC-like efficiency.",
    "RISC dominates in mobile, IoT, and battery-powered devices due to its energy efficiency.",
    "CISC still leads in general-purpose and high-performance computing.",
    "RISC-V is rapidly growing as a free, open-source alternative with huge industry adoption.",
    "Today, the line between RISC and CISC has become heavily blurred."
]
for i, point in enumerate(modern_points):
    if i == 0:
        p = tf.paragraphs[0]
    else:
        p = tf.add_paragraph()
    p.text = "• " + point
    p.font.size = Pt(24)

notes = slide.notes_slide.notes_text_frame
notes.text = "RISC VS CISC IN MODERN ERA (40-50 seconds)\n\nSay: \"Interestingly, the rivalry has evolved. Modern x86 chips are technically CISC on the outside, but internally, they behave a lot like RISC. They break down complex instructions into simpler micro-operations. Meanwhile, RISC has taken over mobile computing. And with RISC-V being open-source, it's becoming a big player in embedded systems and even in custom chips. So rather than competing, modern processors have blended both philosophies.\"\n\nTip: This is a great slide to show 'convergence' - very important point."

# Slide 11: Conclusion
slide = prs.slides.add_slide(prs.slide_layouts[1])
slide.shapes.title.text = "Conclusion"
slide.shapes.title.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 82, 180)
tf = slide.placeholders[1].text_frame
tf.clear()
conclusion_points = [
    "RISC is simpler, faster, and more power-efficient - ideal for mobile and embedded systems.",
    "CISC is powerful, compact in code, and highly compatible - ideal for PCs and servers.",
    "Neither is strictly superior; both have their strengths and limitations.",
    "Modern processors use a hybrid approach, combining RISC efficiency with CISC flexibility.",
    "Ultimately, the choice depends on the specific requirements of the system."
]
for i, point in enumerate(conclusion_points):
    if i == 0:
        p = tf.paragraphs[0]
    else:
        p = tf.add_paragraph()
    p.text = "• " + point
    p.font.size = Pt(26)

notes = slide.notes_slide.notes_text_frame
notes.text = "CONCLUSION (30-40 seconds)\n\nSay: \"To sum up, RISC and CISC are two different approaches to processor design. RISC focuses on speed and efficiency, while CISC focuses on versatility and code density. In practice, modern CPUs don't strictly follow one - they adopt a hybrid model to get the best of both. So, it's not about 'which is better', but 'which is better suited for a particular purpose'.\"\n\nTip: End with a strong, concise summary."

# Slide 12: References
slide = prs.slides.add_slide(prs.slide_layouts[1])
slide.shapes.title.text = "References"
slide.shapes.title.text_frame.paragraphs[0].font.color.rgb = RGBColor(0, 82, 180)
tf = slide.placeholders[1].text_frame
tf.clear()
refs = [
    "Patterson, D.A. & Hennessy, J.L. - Computer Organization and Design (RISC-V Edition)",
    "Stallings, W. - Computer Organization and Architecture, 11th Edition",
    "GeeksforGeeks - Difference Between RISC and CISC Processor (https://www.geeksforgeeks.org/)",
    "ARM Developer Documentation - https://developer.arm.com/",
    "RISC-V International - https://riscv.org/"
]
for i, ref in enumerate(refs):
    if i == 0:
        p = tf.paragraphs[0]
    else:
        p = tf.add_paragraph()
    p.text = "• " + ref
    p.font.size = Pt(22)

notes = slide.notes_slide.notes_text_frame
notes.text = "REFERENCES (5-10 seconds)\n\nSay: \"These are the sources we referred to for this presentation. Thank you all for your time. I'd be happy to take any questions.\"\n\nTip: After this, pause for questions."

output_path = r"C:\Users\hp\Documents\Default Project\Comparative Study of RISC and CISC - Attractive with Design.pptx"
prs.save(output_path)
print("DONE")
