import os
os.chdir(r'C:\Users\hp\Documents\Default Project')
from app import app, init_db
init_db()
print('DATABASE_INITIALIZED')
