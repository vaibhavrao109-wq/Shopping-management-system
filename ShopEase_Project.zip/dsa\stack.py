"""
Stack implementation for Shopping Action History
Demonstrates LIFO (Last In First Out) principle
"""
from typing import Any, Optional, List

class Stack:
    """
    Manual Stack implementation using Python list
    Demonstrates LIFO (Last In First Out) principle
    Used for: Shopping action history
    """
    def __init__(self, max_size=100):
        self.stack_items = []
        self.max_size = max_size
    
    def push(self, action: Any) -> bool:
        """Push action onto stack (LIFO)"""
        if len(self.stack_items) >= self.max_size:
            # Remove oldest if exceeding max size
            self.stack_items.pop(0)
        self.stack_items.append(action)
        return True
    
    def pop(self) -> Optional[Any]:
        """Pop action from stack (LIFO) - removes most recent"""
        if self.is_empty():
            return None
        return self.stack_items.pop()
    
    def peek(self) -> Optional[Any]:
        """View top of stack without removing"""
        if self.is_empty():
            return None
        return self.stack_items[-1]
    
    def is_empty(self) -> bool:
        """Check if stack is empty"""
        return len(self.stack_items) == 0
    
    def size(self) -> int:
        """Return size of stack"""
        return len(self.stack_items)
    
    def clear(self):
        """Clear all items from stack"""
        self.stack_items.clear()
    
    def get_all(self) -> List:
        """Get all items (bottom to top)"""
        return list(self.stack_items)
    
    def get_history_recent_first(self) -> List:
        """Get history from most recent to oldest (demonstrates LIFO view)"""
        return list(reversed(self.stack_items))
    
    def to_dict(self):
        """Convert stack state to dict for demonstration"""
        return {
            'type': 'Stack (LIFO)',
            'size': self.size(),
            'is_empty': self.is_empty(),
            'top': str(self.peek()) if self.peek() else None,
            'items_bottom_to_top': [str(item) for item in self.get_all()],
            'items_recent_first': [str(item) for item in self.get_history_recent_first()]
        }
