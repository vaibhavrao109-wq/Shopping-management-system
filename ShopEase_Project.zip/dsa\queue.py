"""
Queue implementation for Order Processing
Demonstrates FIFO (First In First Out) principle
"""
from typing import Any, Optional, List

class Queue:
    """
    Manual Queue implementation using Python list
    Demonstrates FIFO (First In First Out) principle
    Used for: Order processing
    """
    def __init__(self, max_size=1000):
        self.queue_items = []
        self.max_size = max_size
    
    def enqueue(self, order: Any) -> bool:
        """Add order to rear of queue (FIFO)"""
        if len(self.queue_items) >= self.max_size:
            return False
        self.queue_items.append(order)
        return True
    
    def dequeue(self) -> Optional[Any]:
        """Remove order from front of queue (FIFO)"""
        if self.is_empty():
            return None
        return self.queue_items.pop(0)
    
    def front(self) -> Optional[Any]:
        """View front of queue without removing"""
        if self.is_empty():
            return None
        return self.queue_items[0]
    
    def rear(self) -> Optional[Any]:
        """View rear of queue without removing"""
        if self.is_empty():
            return None
        return self.queue_items[-1]
    
    def is_empty(self) -> bool:
        """Check if queue is empty"""
        return len(self.queue_items) == 0
    
    def size(self) -> int:
        """Return size of queue"""
        return len(self.queue_items)
    
    def clear(self):
        """Clear all items from queue"""
        self.queue_items.clear()
    
    def get_all(self) -> List:
        """Get all items in FIFO order"""
        return list(self.queue_items)
    
    def to_dict(self):
        """Convert queue state to dict for demonstration"""
        return {
            'type': 'Queue (FIFO)',
            'size': self.size(),
            'is_empty': self.is_empty(),
            'front': str(self.front()) if self.front() else None,
            'rear': str(self.rear()) if self.rear() else None,
            'items_fifo_order': [str(item) for item in self.get_all()]
        }
