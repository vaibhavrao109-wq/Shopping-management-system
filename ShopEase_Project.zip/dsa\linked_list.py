"""
Doubly Linked List implementation for Product Catalogue
Demonstrates: insertion, deletion, traversal, search
"""
from typing import Optional, List

class Node:
    """
    Node class for Doubly Linked List
    Each node contains: previous node, product data, next node
    """
    def __init__(self, prev=None, data=None, next_node=None):
        self.prev = prev
        self.data = data  # Can store product dict/object
        self.next = next_node
    
    def __repr__(self):
        if self.data:
            prod_id = self.data.get('id') if isinstance(self.data, dict) else getattr(self.data, 'id', 'N/A')
            return f"Node(id={prod_id})"
        return "Node(None)"


class DoublyLinkedList:
    """
    Doubly Linked List to manage products
    Implements: insertion, deletion, traversal, search operations
    """
    def __init__(self, name="ProductList"):
        self.head: Optional[Node] = None
        self.tail: Optional[Node] = None
        self.name = name
        self.count = 0
    
    def is_empty(self):
        """Check if list is empty"""
        return self.head is None
    
    def insert_at_end(self, product_data):
        """
        Insert a product at the end of doubly linked list
        Maintains proper prev and next references
        """
        new_node = Node(prev=None, data=product_data, next_node=None)
        
        if self.is_empty():
            # If list is empty, head and tail both point to new node
            self.head = new_node
            self.tail = new_node
            self.count += 1
            return True
        else:
            # Insert at end - link tail to new node and new node to tail
            self.tail.next = new_node
            new_node.prev = self.tail
            self.tail = new_node
            self.count += 1
            return True
    
    def insert_at_beginning(self, product_data):
        """Insert a product at the beginning of doubly linked list"""
        new_node = Node(prev=None, data=product_data, next_node=None)
        
        if self.is_empty():
            self.head = new_node
            self.tail = new_node
            self.count += 1
            return True
        else:
            new_node.next = self.head
            self.head.prev = new_node
            self.head = new_node
            self.count += 1
            return True
    
    def display_forward(self) -> List:
        """Display/traverse all products in forward direction"""
        result = []
        if self.is_empty():
            return result
        
        current = self.head
        while current is not None:
            result.append(current.data)
            current = current.next
        return result
    
    def display_backward(self) -> List:
        """Traverse all products in backward direction (demonstrates doubly link)"""
        result = []
        if self.is_empty():
            return result
        
        current = self.tail
        while current is not None:
            result.append(current.data)
            current = current.prev
        return result
    
    def search_by_id(self, product_id):
        """
        Search for product by ID
        Returns product data if found, None otherwise
        """
        if self.is_empty():
            return None
        
        current = self.head
        while current is not None:
            data = current.data
            pid = data.get('id') if isinstance(data, dict) else getattr(data, 'id', None)
            if pid == product_id:
                return data
            current = current.next
        return None
    
    def search_by_name(self, product_name):
        """
        Search for product by name (case-insensitive)
        Returns list of matching products
        """
        results = []
        if self.is_empty():
            return results
        
        current = self.head
        search_name = product_name.lower()
        while current is not None:
            data = current.data
            name = data.get('name') if isinstance(data, dict) else getattr(data, 'name', '')
            if search_name in str(name).lower():
                results.append(data)
            current = current.next
        return results
    
    def remove_by_id(self, product_id):
        """
        Remove product by ID
        Returns True if removed successfully, False otherwise
        Maintains correct prev and next references
        """
        if self.is_empty():
            return False
        
        current = self.head
        
        # Traverse to find the node to remove
        while current is not None:
            data = current.data
            pid = data.get('id') if isinstance(data, dict) else getattr(data, 'id', None)
            if pid == product_id:
                # Case 1: Removing head node
                if current == self.head and current == self.tail:
                    # Only one node in list
                    self.head = None
                    self.tail = None
                elif current == self.head:
                    # Removing head
                    self.head = current.next
                    if self.head:
                        self.head.prev = None
                    current.next = None
                # Case 2: Removing tail node
                elif current == self.tail:
                    # Removing tail
                    self.tail = current.prev
                    if self.tail:
                        self.tail.next = None
                    current.prev = None
                # Case 3: Removing middle node
                else:
                    # Link previous node to next node
                    if current.prev:
                        current.prev.next = current.next
                    if current.next:
                        current.next.prev = current.prev
                    current.prev = None
                    current.next = None
                
                self.count -= 1
                return True
            current = current.next
        
        return False
    
    def get_all(self) -> List:
        """Get all products as list"""
        return self.display_forward()
    
    def to_dict(self):
        """Convert list state to dict for demonstration"""
        return {
            'name': self.name,
            'count': self.count,
            'is_empty': self.is_empty(),
            'forward_traversal': [
                {'id': (d.get('id') if isinstance(d, dict) else getattr(d,'id')),
                 'name': (d.get('name') if isinstance(d, dict) else getattr(d,'name'))}
                for d in self.display_forward()
            ],
            'backward_traversal': [
                {'id': (d.get('id') if isinstance(d, dict) else getattr(d,'id')),
                 'name': (d.get('name') if isinstance(d, dict) else getattr(d,'name'))}
                for d in self.display_backward()
            ]
        }
