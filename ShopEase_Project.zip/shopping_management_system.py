# SHOPPING MANAGEMENT SYSTEM
# Enhanced and Corrected Version with Proper DSA Implementation

import sys
sys.setrecursionlimit(10**7)

# ==================== PRODUCT CLASS ====================
class Product:
    """
    Product class to hold product information
    Attributes: id, name, brand, price
    """
    def __init__(self, pid, pname, pbrand, pprice):
        self.id = pid
        self.name = pname
        self.brand = pbrand
        self.price = pprice
    
    def display(self):
        """Display product details"""
        print(f"ID: {self.id} | Name: {self.name} | Brand: {self.brand} | Price: Rs.{self.price}")

# ==================== NODE CLASS FOR DOUBLY LINKED LIST ====================
class Node:
    """
    Node class for Doubly Linked List
    Each node contains: previous node, product data, next node
    """
    def __init__(self, prev=None, data=None, next=None):
        self.prev = prev
        self.data = data  # Stores Product object
        self.next = next

# ==================== DOUBLY LINKED LIST CLASS ====================
class DoublyLinkedList:
    """
    Doubly Linked List to manage products in each category
    Implements: insertion, deletion, traversal, search operations
    """
    def __init__(self, category_name=""):
        self.head = None
        self.tail = None
        self.category_name = category_name
        self.count = 0
    
    def is_empty(self):
        """Check if list is empty"""
        return self.head is None
    
    def insert_at_end(self, product):
        """
        Insert a product at the end of doubly linked list
        Maintains proper prev and next references
        """
        new_node = Node(prev=None, data=product, next=None)
        
        if self.is_empty():
            # If list is empty, head and tail both point to new node
            self.head = new_node
            self.tail = new_node
            self.count += 1
            return True
        else:
            # Insert at end - link tail to new node and new node to tail
            self.tail.next = new_node
            new_node.prev = self.tail
            self.tail = new_node
            self.count += 1
            return True
    
    def insert_at_beginning(self, product):
        """Insert a product at the beginning of doubly linked list"""
        new_node = Node(prev=None, data=product, next=None)
        
        if self.is_empty():
            self.head = new_node
            self.tail = new_node
            self.count += 1
            return True
        else:
            new_node.next = self.head
            self.head.prev = new_node
            self.head = new_node
            self.count += 1
            return True
    
    def display_forward(self):
        """Display all products in forward direction"""
        if self.is_empty():
            print(f"  [No products in {self.category_name} category]")
            return
        
        print(f"\n=== {self.category_name} ===")
        current = self.head
        index = 1
        while current is not None:
            print(f"  {index}.", end=" ")
            current.data.display()
            current = current.next
            index += 1
    
    def search_by_id(self, product_id):
        """
        Search for product by ID
        Returns product object if found, None otherwise
        """
        if self.is_empty():
            return None
        
        current = self.head
        while current is not None:
            if current.data.id == product_id:
                return current.data
            current = current.next
        return None
    
    def search_by_name(self, product_name):
        """
        Search for product by name (case-insensitive)
        Returns list of matching products
        """
        results = []
        if self.is_empty():
            return results
        
        current = self.head
        search_name = product_name.lower()
        while current is not None:
            if search_name in current.data.name.lower():
                results.append(current.data)
            current = current.next
        return results
    
    def remove_by_id(self, product_id):
        """
        Remove product by ID
        Returns True if removed successfully, False otherwise
        Maintains correct prev and next references
        """
        if self.is_empty():
            return False
        
        current = self.head
        
        # Traverse to find the node to remove
        while current is not None:
            if current.data.id == product_id:
                # Case 1: Removing head node
                if current == self.head and current == self.tail:
                    # Only one node in list
                    self.head = None
                    self.tail = None
                elif current == self.head:
                    # Removing head
                    self.head = current.next
                    self.head.prev = None
                    current.next = None
                # Case 2: Removing tail node
                elif current == self.tail:
                    # Removing tail
                    self.tail = current.prev
                    self.tail.next = None
                    current.prev = None
                # Case 3: Removing middle node
                else:
                    # Link previous node to next node
                    current.prev.next = current.next
                    current.next.prev = current.prev
                    current.prev = None
                    current.next = None
                
                self.count -= 1
                return True
            current = current.next
        
        return False
    
    def get_all_products(self):
        """Return list of all product objects in this list"""
        products = []
        if self.is_empty():
            return products
        
        current = self.head
        while current is not None:
            products.append(current.data)
            current = current.next
        return products

# ==================== CART ITEM CLASS ====================
class CartItem:
    """Represents an item in the shopping cart"""
    def __init__(self, product, quantity):
        self.product = product
        self.quantity = quantity
    
    def get_subtotal(self):
        """Calculate subtotal for this cart item"""
        return self.product.price * self.quantity
    
    def display(self):
        """Display cart item details"""
        print(f"  ID: {self.product.id} | {self.product.name} ({self.product.brand}) | "
              f"Qty: {self.quantity} | Unit: Rs.{self.product.price} | "
              f"Subtotal: Rs.{self.get_subtotal()}")

# ==================== SHOPPING CART CLASS ====================
class ShoppingCart:
    """Shopping cart to manage items added by customer"""
    def __init__(self):
        self.items = []  # List of CartItem objects
    
    def add_item(self, product, quantity):
        """
        Add product to cart
        If product already exists, update quantity
        """
        if quantity <= 0:
            print("  [Error] Quantity must be positive!")
            return False
        
        # Check if product already in cart
        for item in self.items:
            if item.product.id == product.id:
                item.quantity += quantity
                print(f"  [Updated] {product.name} quantity updated to {item.quantity}")
                return True
        
        # Add new item to cart
        cart_item = CartItem(product, quantity)
        self.items.append(cart_item)
        print(f"  [Added] {product.name} x{quantity} added to cart!")
        return True
    
    def remove_item(self, product_id):
        """Remove item from cart by product ID"""
        for i, item in enumerate(self.items):
            if item.product.id == product_id:
                removed_item = self.items.pop(i)
                print(f"  [Removed] {removed_item.product.name} removed from cart!")
                return True
        print("  [Error] Item not found in cart!")
        return False
    
    def update_quantity(self, product_id, new_quantity):
        """Update quantity of item in cart"""
        if new_quantity <= 0:
            print("  [Error] Quantity must be positive! Use remove option instead.")
            return False
        
        for item in self.items:
            if item.product.id == product_id:
                item.quantity = new_quantity
                print(f"  [Updated] Quantity updated to {new_quantity}")
                return True
        print("  [Error] Item not found in cart!")
        return False
    
    def view_cart(self):
        """Display all items in cart with totals"""
        if len(self.items) == 0:
            print("\n=== SHOPPING CART ===")
            print("  [Cart is empty]")
            return False
        
        print("\n=== SHOPPING CART ===")
        total = 0
        for i, item in enumerate(self.items, 1):
            print(f"  {i}.", end=" ")
            item.display()
            total += item.get_subtotal()
        
        print("  " + "-" * 60)
        print(f"  GRAND TOTAL: Rs.{total}")
        print("  " + "-" * 60)
        return True
    
    def get_total(self):
        """Calculate grand total"""
        total = 0
        for item in self.items:
            total += item.get_subtotal()
        return total
    
    def is_empty(self):
        """Check if cart is empty"""
        return len(self.items) == 0
    
    def clear_cart(self):
        """Clear all items from cart"""
        self.items.clear()
        print("  [Cart cleared]")

# ==================== STACK CLASS (LIFO) ====================
class Stack:
    """
    Stack implementation using Python list
    Demonstrates LIFO (Last In First Out) principle
    Used for: Shopping action history/undo
    """
    def __init__(self):
        self.stack_items = []
    
    def push(self, action):
        """Push action onto stack (LIFO)"""
        self.stack_items.append(action)
        print(f"  [Action Logged] {action}")
    
    def pop(self):
        """Pop action from stack (LIFO) - removes most recent"""
        if self.is_empty():
            return None
        action = self.stack_items.pop()
        return action
    
    def peek(self):
        """View top of stack without removing"""
        if self.is_empty():
            return None
        return self.stack_items[-1]
    
    def is_empty(self):
        """Check if stack is empty"""
        return len(self.stack_items) == 0
    
    def display_history(self):
        """Display action history from most recent to oldest"""
        if self.is_empty():
            print("\n=== ACTION HISTORY ===")
            print("  [No actions yet]")
            return
        
        print("\n=== RECENT ACTIONS (Most Recent First) ===")
        # Display in reverse order (LIFO view)
        for i, action in enumerate(reversed(self.stack_items), 1):
            print(f"  {i}. {action}")

# ==================== QUEUE CLASS (FIFO) ====================
class Queue:
    """
    Queue implementation using Python list
    Demonstrates FIFO (First In First Out) principle
    Used for: Order processing/checkout queue
    """
    def __init__(self):
        self.queue_items = []
    
    def enqueue(self, order):
        """Add order to rear of queue (FIFO)"""
        self.queue_items.append(order)
        print(f"  [Order Queued] Order #{order['order_id']} added to processing queue")
    
    def dequeue(self):
        """Remove order from front of queue (FIFO)"""
        if self.is_empty():
            return None
        order = self.queue_items.pop(0)
        return order
    
    def front(self):
        """View front of queue without removing"""
        if self.is_empty():
            return None
        return self.queue_items[0]
    
    def is_empty(self):
        """Check if queue is empty"""
        return len(self.queue_items) == 0
    
    def display_queue(self):
        """Display orders in queue (FIFO order)"""
        if self.is_empty():
            print("\n=== ORDER PROCESSING QUEUE ===")
            print("  [Queue is empty]")
            return
        
        print("\n=== ORDER PROCESSING QUEUE (FIFO Order) ===")
        for i, order in enumerate(self.queue_items, 1):
            print(f"  {i}. Order #{order['order_id']} | Items: {len(order['items'])} | "
                  f"Total: Rs.{order['total']} | Status: {order['status']}")

# ==================== SHOPPING MANAGEMENT SYSTEM CLASS ====================
class ShoppingManagementSystem:
    """
    Main class to coordinate all operations
    Manages menus, categories, cart, admin functions
    """
    def __init__(self):
        # Create category-linked lists
        self.jeans_list = DoublyLinkedList("Jeans")
        self.trousers_list = DoublyLinkedList("Trousers")
        self.shirts_list = DoublyLinkedList("Shirts")
        self.tshirts_list = DoublyLinkedList("T-Shirts")
        self.watches_list = DoublyLinkedList("Watches")
        self.shoes_list = DoublyLinkedList("Shoes")
        
        # Dictionary to map category choice to linked list
        self.categories = {
            1: ("Jeans", self.jeans_list),
            2: ("Trousers", self.trousers_list),
            3: ("Shirts", self.shirts_list),
            4: ("T-Shirts", self.tshirts_list),
            5: ("Watches", self.watches_list),
            6: ("Shoes", self.shoes_list)
        }
        
        # Shopping cart
        self.cart = ShoppingCart()
        
        # DSA structures for demonstration
        self.action_stack = Stack()  # For action history (LIFO)
        self.order_queue = Queue()    # For order processing (FIFO)
        
        self.order_counter = 1000
        
        # Initialize all products
        self.initialize_products()
    
    def initialize_products(self):
        """Initialize all products with corrected data and unique IDs"""
        # JEANS (Category 1)
        self.jeans_list.insert_at_end(Product(101, "Slim Fit Black Jeans", "Denim", 2499))
        self.jeans_list.insert_at_end(Product(102, "Regular Fit Blue Jeans", "Levis", 2999))
        self.jeans_list.insert_at_end(Product(103, "Ripped Black Jeans", "Wrangler", 3499))
        self.jeans_list.insert_at_end(Product(104, "Straight Fit Grey Jeans", "Pepe Jeans", 2799))
        self.jeans_list.insert_at_end(Product(105, "Skinny Fit Blue Jeans", "Spykar", 3199))
        
        # TROUSERS (Category 2)
        self.trousers_list.insert_at_end(Product(201, "Formal Black Trouser", "Van Heusen", 1999))
        self.trousers_list.insert_at_end(Product(202, "Chino Khaki Trouser", "Raymond", 2299))
        self.trousers_list.insert_at_end(Product(203, "Casual Grey Trouser", "Peter England", 1799))
        self.trousers_list.insert_at_end(Product(204, "Cargo Beige Trouser", "Flying Machine", 2499))
        self.trousers_list.insert_at_end(Product(205, "Track Pant Black", "Puma", 1599))
        
        # SHIRTS (Category 3)
        self.shirts_list.insert_at_end(Product(301, "Formal White Shirt", "Arrow", 1899))
        self.shirts_list.insert_at_end(Product(302, "Checked Blue Shirt", "Van Heusen", 1799))
        self.shirts_list.insert_at_end(Product(303, "Striped Black Shirt", "Raymond", 1999))
        self.shirts_list.insert_at_end(Product(304, "Denim Casual Shirt", "Levis", 2199))
        self.shirts_list.insert_at_end(Product(305, "Plain Maroon Shirt", "Peter England", 1699))
        
        # T-SHIRTS (Category 4)
        self.tshirts_list.insert_at_end(Product(401, "Round Neck Black T-Shirt", "Nike", 1299))
        self.tshirts_list.insert_at_end(Product(402, "V-Neck White T-Shirt", "Puma", 1099))
        self.tshirts_list.insert_at_end(Product(403, "Graphic Blue T-Shirt", "Adidas", 1499))
        self.tshirts_list.insert_at_end(Product(404, "Polo Green T-Shirt", "Levis", 1599))
        self.tshirts_list.insert_at_end(Product(405, "Crew Neck Brown T-Shirt", "HRX", 999))
        
        # WATCHES (Category 5)
        self.watches_list.insert_at_end(Product(501, "Classic Black Watch", "Titan", 3999))
        self.watches_list.insert_at_end(Product(502, "Smart Watch Silver", "Fastrack", 5999))
        self.watches_list.insert_at_end(Product(503, "Chronograph Brown Watch", "Casio", 8999))
        self.watches_list.insert_at_end(Product(504, "Minimalist Golden Watch", "Sonata", 2499))
        self.watches_list.insert_at_end(Product(505, "Digital Sports Watch", "Noise", 4999))
        
        # SHOES (Category 6)
        self.shoes_list.insert_at_end(Product(601, "Running Black Shoes", "Nike", 6999))
        self.shoes_list.insert_at_end(Product(602, "Casual White Shoes", "Adidas", 6499))
        self.shoes_list.insert_at_end(Product(603, "Training Blue Shoes", "Puma", 5999))
        self.shoes_list.insert_at_end(Product(604, "Formal Brown Shoes", "Bata", 3999))
        self.shoes_list.insert_at_end(Product(605, "Sneakers Grey Shoes", "Sparx", 2999))
        
        print("  [System] Product catalogue initialized successfully!")
    
    def get_all_categories_lists(self):
        """Return all category linked lists"""
        return [
            self.jeans_list, self.trousers_list, self.shirts_list,
            self.tshirts_list, self.watches_list, self.shoes_list
        ]
    
    def search_product_by_id(self, product_id):
        """Search product across all categories by ID"""
        for cat_list in self.get_all_categories_lists():
            product = cat_list.search_by_id(product_id)
            if product is not None:
                return product
        return None
    
    def search_product_by_name(self, product_name):
        """Search product across all categories by name"""
        results = []
        for cat_list in self.get_all_categories_lists():
            results.extend(cat_list.search_by_name(product_name))
        return results
    
    def display_all_catalogue(self):
        """Display entire product catalogue"""
        print("\n" + "=" * 60)
        print("           COMPLETE PRODUCT CATALOGUE")
        print("=" * 60)
        for cat_list in self.get_all_categories_lists():
            cat_list.display_forward()
        print("=" * 60)
    
    def browse_by_category(self):
        """Browse products by category"""
        print("\n" + "=" * 60)
        print("              BROWSE BY CATEGORY")
        print("=" * 60)
        print("  1. Jeans")
        print("  2. Trousers")
        print("  3. Shirts")
        print("  4. T-Shirts")
        print("  5. Watches")
        print("  6. Shoes")
        print("  7. Back to Main Menu")
        print("=" * 60)
        
        try:
            choice = int(input("\n  Enter your choice: "))
            if choice == 7:
                return
            
            if choice in self.categories:
                cat_name, cat_list = self.categories[choice]
                cat_list.display_forward()
                
                # Option to add to cart
                add_choice = input("\n  Do you want to add a product to cart? (y/n): ").lower()
                if add_choice == 'y':
                    self.add_product_to_cart_from_category(cat_list)
            else:
                print("  [Error] Invalid choice!")
        except ValueError:
            print("  [Error] Please enter a valid number!")
        except Exception as e:
            print(f"  [Error] {e}")
    
    def add_product_to_cart_from_category(self, cat_list):
        """Add product to cart from selected category"""
        try:
            pid = int(input("  Enter Product ID: "))
            product = cat_list.search_by_id(pid)
            
            if product is None:
                print("  [Error] Product not found in this category!")
                return
            
            qty = int(input("  Enter Quantity: "))
            if qty <= 0:
                print("  [Error] Quantity must be positive!")
                return
            
            # Add to cart
            if self.cart.add_item(product, qty):
                # Log action in stack (LIFO demonstration)
                self.action_stack.push(f"Added {product.name} (ID:{product.id}) x{qty} to cart")
            
        except ValueError:
            print("  [Error] Please enter valid numbers!")
        except Exception as e:
            print(f"  [Error] {e}")
    
    def search_product_menu(self):
        """Search for product menu"""
        print("\n" + "=" * 60)
        print("                SEARCH PRODUCT")
        print("=" * 60)
        print("  1. Search by Product ID")
        print("  2. Search by Product Name")
        print("  3. Back to Main Menu")
        print("=" * 60)
        
        try:
            choice = int(input("\n  Enter your choice: "))
            
            if choice == 1:
                pid = int(input("  Enter Product ID: "))
                product = self.search_product_by_id(pid)
                if product is None:
                    print("  [Not Found] No product found with this ID!")
                else:
                    print("\n  [Product Found]")
                    product.display()
                    add_choice = input("\n  Add to cart? (y/n): ").lower()
                    if add_choice == 'y':
                        qty = int(input("  Enter Quantity: "))
                        if qty > 0 and self.cart.add_item(product, qty):
                            self.action_stack.push(f"Added {product.name} (ID:{product.id}) x{qty} to cart")
            
            elif choice == 2:
                name = input("  Enter Product Name (or keyword): ")
                results = self.search_product_by_name(name)
                if len(results) == 0:
                    print("  [Not Found] No products found!")
                else:
                    print(f"\n  [Found {len(results)} product(s)]")
                    for i, prod in enumerate(results, 1):
                        print(f"  {i}.", end=" ")
                        prod.display()
                    
                    add_choice = input("\n  Add to cart? (y/n): ").lower()
                    if add_choice == 'y':
                        pid = int(input("  Enter Product ID to add: "))
                        product = self.search_product_by_id(pid)
                        if product:
                            qty = int(input("  Enter Quantity: "))
                            if qty > 0 and self.cart.add_item(product, qty):
                                self.action_stack.push(f"Added {product.name} (ID:{product.id}) x{qty} to cart")
                        else:
                            print("  [Error] Invalid Product ID!")
            elif choice == 3:
                return
            else:
                print("  [Error] Invalid choice!")
        except ValueError:
            print("  [Error] Please enter valid input!")
        except Exception as e:
            print(f"  [Error] {e}")
    
    def cart_menu(self):
        """Shopping cart menu"""
        while True:
            print("\n" + "=" * 60)
            print("                SHOPPING CART MENU")
            print("=" * 60)
            print("  1. View Cart")
            print("  2. Update Quantity")
            print("  3. Remove Item")
            print("  4. Clear Cart")
            print("  5. Proceed to Checkout")
            print("  6. Back to Main Menu")
            print("=" * 60)
            
            try:
                choice = int(input("\n  Enter your choice: "))
                
                if choice == 1:
                    self.cart.view_cart()
                
                elif choice == 2:
                    if self.cart.is_empty():
                        print("  [Cart is empty]")
                        continue
                    self.cart.view_cart()
                    pid = int(input("\n  Enter Product ID to update: "))
                    qty = int(input("  Enter New Quantity: "))
                    if self.cart.update_quantity(pid, qty):
                        product = self.search_product_by_id(pid)
                        if product:
                            self.action_stack.push(f"Updated {product.name} (ID:{pid}) quantity to {qty}")
                
                elif choice == 3:
                    if self.cart.is_empty():
                        print("  [Cart is empty]")
                        continue
                    self.cart.view_cart()
                    pid = int(input("\n  Enter Product ID to remove: "))
                    product = self.search_product_by_id(pid)
                    if self.cart.remove_item(pid) and product:
                        self.action_stack.push(f"Removed {product.name} (ID:{pid}) from cart")
                
                elif choice == 4:
                    if self.cart.is_empty():
                        print("  [Cart is empty]")
                        continue
                    confirm = input("  Are you sure you want to clear cart? (y/n): ").lower()
                    if confirm == 'y':
                        # Log before clearing
                        self.action_stack.push(f"Cleared cart ({len(self.cart.items)} items)")
                        self.cart.clear_cart()
                
                elif choice == 5:
                    self.checkout()
                    break
                
                elif choice == 6:
                    break
                else:
                    print("  [Error] Invalid choice!")
            
            except ValueError:
                print("  [Error] Please enter valid numbers!")
            except Exception as e:
                print(f"  [Error] {e}")
    
    def checkout(self):
        """Process checkout and generate bill"""
        print("\n" + "=" * 60)
        print("                    CHECKOUT")
        print("=" * 60)
        
        if self.cart.is_empty():
            print("  [Error] Cannot checkout with empty cart!")
            return
        
        # Display bill
        print("\n  BILL DETAILS:")
        print("  " + "-" * 58)
        total = 0
        bill_items = []
        for item in self.cart.items:
            subtotal = item.get_subtotal()
            bill_items.append({
                'id': item.product.id,
                'name': item.product.name,
                'brand': item.product.brand,
                'quantity': item.quantity,
                'unit_price': item.product.price,
                'subtotal': subtotal
            })
            print(f"  {item.product.id} | {item.product.name} | {item.product.brand} | "
                  f"Qty:{item.quantity} | Rs.{item.product.price} | Subtotal: Rs.{subtotal}")
            total += subtotal
        
        print("  " + "-" * 58)
        print(f"  GRAND TOTAL: Rs.{total}")
        print("  " + "=" * 58)
        
        # Confirmation
        confirm = input("\n  Confirm order? (y/n): ").lower()
        if confirm == 'y':
            # Create order
            self.order_counter += 1
            order = {
                'order_id': self.order_counter,
                'items': bill_items,
                'total': total,
                'status': 'Pending'
            }
            
            # Add to queue (FIFO demonstration)
            self.order_queue.enqueue(order)
            self.action_stack.push(f"Checkout completed - Order #{self.order_counter}, Total: Rs.{total}")
            
            print("\n  " + "=" * 58)
            print(f"  ORDER CONFIRMED! Order ID: #{self.order_counter}")
            print(f"  Total Amount: Rs.{total}")
            print("  Thank you for shopping with us!")
            print("  " + "=" * 58)
            
            # Clear cart after successful checkout
            self.cart.clear_cart()
        else:
            print("\n  [Checkout Cancelled] Order not placed.")
    
    def admin_menu(self):
        """Admin functionality menu"""
        while True:
            print("\n" + "=" * 60)
            print("                  ADMIN MENU")
            print("=" * 60)
            print("  1. View Full Catalogue")
            print("  2. Add New Product")
            print("  3. Remove Product")
            print("  4. View Action History (Stack - LIFO)")
            print("  5. View Order Queue (Queue - FIFO)")
            print("  6. Process Next Order")
            print("  7. Back to Main Menu")
            print("=" * 60)
            
            try:
                choice = int(input("\n  Enter your choice: "))
                
                if choice == 1:
                    self.display_all_catalogue()
                
                elif choice == 2:
                    self.add_new_product()
                
                elif choice == 3:
                    self.remove_product_admin()
                
                elif choice == 4:
                    self.action_stack.display_history()
                
                elif choice == 5:
                    self.order_queue.display_queue()
                
                elif choice == 6:
                    self.process_next_order()
                
                elif choice == 7:
                    break
                else:
                    print("  [Error] Invalid choice!")
            
            except ValueError:
                print("  [Error] Please enter valid numbers!")
            except Exception as e:
                print(f"  [Error] {e}")
    
    def add_new_product(self):
        """Add new product to catalogue (Admin function)"""
        print("\n" + "=" * 60)
        print("                ADD NEW PRODUCT")
        print("=" * 60)
        print("  Select Category:")
        print("  1. Jeans")
        print("  2. Trousers")
        print("  3. Shirts")
        print("  4. T-Shirts")
        print("  5. Watches")
        print("  6. Shoes")
        print("=" * 60)
        
        try:
            cat_choice = int(input("\n  Enter category: "))
            if cat_choice not in self.categories:
                print("  [Error] Invalid category!")
                return
            
            cat_name, cat_list = self.categories[cat_choice]
            
            # Get product details
            pid = int(input("  Enter Product ID: "))
            
            # Check for duplicate ID
            if self.search_product_by_id(pid) is not None:
                print("  [Error] Product ID already exists! Duplicate IDs not allowed.")
                return
            
            pname = input("  Enter Product Name: ")
            pbrand = input("  Enter Product Brand: ")
            pprice = float(input("  Enter Product Price: Rs."))
            
            if pprice < 0:
                print("  [Error] Price cannot be negative!")
                return
            
            # Create and add product
            new_product = Product(pid, pname, pbrand, int(pprice))
            cat_list.insert_at_end(new_product)
            
            print(f"\n  [Success] Product '{pname}' added to {cat_name} category!")
            self.action_stack.push(f"Admin: Added new product {pname} (ID:{pid}) to {cat_name}")
            
        except ValueError:
            print("  [Error] Please enter valid input!")
        except Exception as e:
            print(f"  [Error] {e}")
    
    def remove_product_admin(self):
        """Remove product from catalogue (Admin function)"""
        print("\n" + "=" * 60)
        print("               REMOVE PRODUCT")
        print("=" * 60)
        
        try:
            pid = int(input("  Enter Product ID to remove: "))
            product = self.search_product_by_id(pid)
            
            if product is None:
                print("  [Error] Product not found!")
                return
            
            # Display product details
            print("\n  Product to remove:")
            product.display()
            
            # Check if in cart
            in_cart = False
            for item in self.cart.items:
                if item.product.id == pid:
                    in_cart = True
                    break
            
            if in_cart:
                print("\n  [Warning] This product is currently in the shopping cart!")
                print("  Removing it from catalogue will not auto-remove from cart,")
                print("  but it won't be available for new selections.")
            
            confirm = input("\n  Confirm removal? (y/n): ").lower()
            if confirm == 'y':
                # Remove from appropriate category list
                removed = False
                for cat_name, cat_list in self.categories.values():
                    if cat_list.remove_by_id(pid):
                        removed = True
                        print(f"\n  [Success] Product removed from {cat_name} category!")
                        self.action_stack.push(f"Admin: Removed product {product.name} (ID:{pid})")
                        break
                
                if not removed:
                    print("  [Error] Failed to remove product!")
            else:
                print("  [Cancelled] Removal cancelled.")
            
        except ValueError:
            print("  [Error] Please enter valid Product ID!")
        except Exception as e:
            print(f"  [Error] {e}")
    
    def process_next_order(self):
        """Process next order from queue (FIFO demonstration)"""
        if self.order_queue.is_empty():
            print("\n  [Queue is empty] No orders to process!")
            return
        
        order = self.order_queue.dequeue()
        if order:
            print("\n" + "=" * 60)
            print(f"              PROCESSING ORDER #{order['order_id']}")
            print("=" * 60)
            print(f"  Items: {len(order['items'])}")
            print(f"  Total: Rs.{order['total']}")
            print(f"  Status: {order['status']} -> Completed")
            print("=" * 60)
            print("  [Order Processed Successfully]")
            self.action_stack.push(f"Processed Order #{order['order_id']}")

# ==================== MAIN FUNCTION ====================
def main():
    """Main function to run the Shopping Management System"""
    print("=" * 60)
    print("      SHOPPING MANAGEMENT SYSTEM")
    print("   (DSA Project - Doubly Linked List, Stack & Queue)")
    print("=" * 60)
    
    sms = ShoppingManagementSystem()
    
    while True:
        print("\n" + "=" * 60)
        print("                  MAIN MENU")
        print("=" * 60)
        print("  1. Browse by Category")
        print("  2. View All Products")
        print("  3. Search Product")
        print("  4. Shopping Cart")
        print("  5. Admin Menu")
        print("  6. Exit")
        print("=" * 60)
        
        try:
            choice = int(input("\n  Enter your choice: "))
            
            if choice == 1:
                sms.browse_by_category()
            
            elif choice == 2:
                sms.display_all_catalogue()
            
            elif choice == 3:
                sms.search_product_menu()
            
            elif choice == 4:
                sms.cart_menu()
            
            elif choice == 5:
                sms.admin_menu()
            
            elif choice == 6:
                print("\n" + "=" * 60)
                print("  Thank you for using Shopping Management System!")
                print("  Goodbye!")
                print("=" * 60)
                break
            else:
                print("  [Error] Invalid choice! Please select 1-6.")
        
        except ValueError:
            print("  [Error] Please enter a valid number!")
        except KeyboardInterrupt:
            print("\n\n  Program interrupted. Goodbye!")
            break
        except Exception as e:
            print(f"  [Error] An unexpected error occurred: {e}")

# ==================== PROGRAM ENTRY POINT ====================
if __name__ == "__main__":
    main()
